#ifndef r9_h
#define r9_h

int soma_r9(long long n);

#endif