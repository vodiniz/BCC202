
void mergesort(char*v, int l, int r);
void merge(char *v, int l, int m, int r);
